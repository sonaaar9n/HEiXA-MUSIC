# HEiXA MUSIC

Offline, lightweight Android music player. Black "Nothing OS" look, dot-matrix accents,
colour-per-song (taken from the artwork) and **zero third-party libraries**.

* Package: `com.heixa.music` · minSdk 26 · targetSdk 34
* No `INTERNET` permission, nothing leaves the phone
* Release APK target: **under 10 MB** (CI fails the build if it is bigger)

## Build without Android Studio (GitHub Actions)

1. Create a repo named `HEIXA-MUSIC` and upload everything from this folder (keep the `.github` folder).
2. Open the **Actions** tab → *Build APK* runs on every push (or press *Run workflow*).
3. When it is green, open the run and download the artifact **HEiXA-MUSIC-apk** (`app-release.apk`).

**Stable signing key (optional but recommended):** a new key is generated on every CI run, so an
update would not install over the previous APK. To keep one key, add repository secrets
`KEYSTORE_BASE64` (`base64 -w0 my.jks`), `KEYSTORE_PASSWORD` and `KEY_ALIAS`
(key password must equal the keystore password).

## Build locally

Android Studio (Hedgehog or newer) → *Open* this folder → Run.
Command line: install Gradle 8.5 + JDK 17, then `gradle :app:assembleRelease`
(or run `gradle wrapper` once to create the Gradle wrapper).

## Code map (`app/src/main/java/com/heixa/music`)

| File | Job |
|---|---|
| `PlayerService.kt` | Whole playback engine: `MediaPlayer`, audio focus, `MediaSession`, notification, headphone-unplug pause, sleep timer, equalizer owner |
| `PlayQueue.kt` | Pure queue logic: next / previous (3 s rule) / shuffle / repeat OFF-ALL-ONE |
| `Library.kt` | One `MediaStore` query, folder grouping, extension filter, corrupt-file guard |
| `EqController.kt` | `Equalizer` on a fixed audio session, presets, saved band levels |
| `MainActivity.kt` | Songs / Folders / search / mini player / permission flow |
| `NowPlayingView.kt` | Full player screen (artwork glow, accent song name, dot-matrix clock) |
| `Palette.kt` | Per-song accent colour (artwork → colour, fallback from title) |
| `DotText.kt` | Tiny 5×7 dot-matrix font + view (logo, clocks only) |
| `Dialogs.kt` | Equalizer, sleep timer, language |
| `Loc.kt` | In-app language (English / हिन्दी) |

### Key design decisions

* **A fresh `MediaPlayer` per song**, old one released → no stale-player "pause then play does nothing".
* **Audio focus is kept while paused**; released only on permanent loss, queue end or stop. Play always re-requests focus.
* **Fixed audio session id** → the equalizer is attached once and survives song changes.
* **Notification:** playing = foreground + ongoing; paused = detached and swipeable; swipe or `onTaskRemoved` while not playing = full stop (`stopSelf`), so no ghost process.
* **Sleep timer** uses `SystemClock.elapsedRealtime()` (no drift, immune to clock changes).
* **Broken file** → skipped with a toast; if every song fails the player stops (no infinite loop).
* **Permissions:** `READ_MEDIA_AUDIO` (13+), `READ_EXTERNAL_STORAGE` (≤12), `POST_NOTIFICATIONS`; "don't ask again" opens app settings.

## Adding a language

Copy `res/values/strings.xml` to `res/values-xx/strings.xml`, translate, add `"xx"` to
`resourceConfigurations` in `app/build.gradle.kts` and to the list in `Dialogs.language`.
