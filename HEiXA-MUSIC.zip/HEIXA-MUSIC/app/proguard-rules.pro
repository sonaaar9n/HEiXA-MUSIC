-dontwarn kotlin.**
# Strip Kotlin null-check intrinsics: smaller and faster.
-assumenosideeffects class kotlin.jvm.internal.Intrinsics {
    public static void check*(...);
    public static void throw*(...);
}
