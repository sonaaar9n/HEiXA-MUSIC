package com.heixa.music

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

object Colors {
    const val BG = Color.BLACK
    val CARD = 0xFF121212.toInt()
    val DIM = 0xFF8E8E93.toInt()
    val RED = 0xFFD71921.toInt()
}

/** 03:45 or 1:03:45 (always ASCII digits so the dot font can draw it). */
fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

/** 1h 12m / 45m */
fun fmtLong(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

fun Context.pill(color: Int, radiusDp: Int): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

fun Context.iconButton(res: Int, sizeDp: Int, tint: Int, desc: Int, onClick: (View) -> Unit): ImageButton {
    val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
    return ImageButton(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, mask)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        val p = dp(sizeDp / 4)
        setPadding(p, p, p, p)
        contentDescription = getString(desc)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        setOnClickListener { onClick(it) }
    }
}

/** One list row. [key] is a track id (songs) or a negative number (folders). */
class Row(val key: Long, val title: String, val sub: String)

/** Plain two-line list. The playing song's title is painted in the Apple-Music-style accent. */
class RowAdapter(private val ctx: Context) : BaseAdapter() {
    private class Holder(val title: TextView, val sub: TextView)

    private var rows: List<Row> = emptyList()
    var playingKey: Long = Long.MIN_VALUE
    var playingColor: Int = Palette.DEFAULT

    fun submit(list: List<Row>) { rows = list; notifyDataSetChanged() }

    override fun getCount() = rows.size
    override fun getItem(position: Int): Any = rows[position]
    override fun getItemId(position: Int): Long = rows[position].key

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v: View
        val h: Holder
        if (convertView == null) {
            val t = TextView(ctx).apply {
                textSize = 16f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val s = TextView(ctx).apply {
                textSize = 13f
                setTextColor(Colors.DIM)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            v = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(ctx.dp(20), ctx.dp(11), ctx.dp(20), ctx.dp(11))
                addView(t)
                addView(s)
            }
            h = Holder(t, s)
            v.tag = h
        } else {
            v = convertView
            h = v.tag as Holder
        }
        val r = rows[position]
        h.title.text = r.title
        h.sub.text = r.sub
        h.title.setTextColor(if (r.key == playingKey) Palette.text(playingColor) else Color.WHITE)
        return v
    }
}
