package com.heixa.music

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** One audio file. [artist] is "" when the tag is missing. */
class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val folder: String get() = path.substringBeforeLast('/', "")

    fun artistLabel(ctx: Context): String = artist.ifEmpty { ctx.getString(R.string.unknown_artist) }
}

class Folder(val path: String, val tracks: List<Track>) {
    val name: String = path.substringAfterLast('/').ifEmpty { "/" }
    val totalMs: Long = tracks.sumOf { it.durationMs }
}
