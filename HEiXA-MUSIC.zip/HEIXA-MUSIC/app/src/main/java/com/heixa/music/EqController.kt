package com.heixa.music

import android.content.SharedPreferences
import android.media.audiofx.Equalizer

/** Wraps android.media.audiofx.Equalizer bound to one fixed audio session. Never throws. */
class EqController(sessionId: Int, private val prefs: SharedPreferences) {
    private var eq: Equalizer? = null
    var bandCount = 0; private set
    var minMb = 0; private set
    var maxMb = 0; private set

    val available: Boolean get() = eq != null
    var enabled: Boolean = false; private set
    /** -1 = custom band levels, otherwise a built-in preset index. */
    var preset: Int = -1; private set

    init {
        try {
            if (sessionId > 0) {
                val e = Equalizer(0, sessionId)
                eq = e
                bandCount = e.numberOfBands.toInt()
                minMb = e.bandLevelRange[0].toInt()
                maxMb = e.bandLevelRange[1].toInt()
                enabled = prefs.getBoolean("eq_on", false)
                preset = prefs.getInt("eq_preset", -1)
                e.enabled = enabled
                if (preset in 0 until e.numberOfPresets) {
                    e.usePreset(preset.toShort())
                } else {
                    preset = -1
                    for (b in 0 until bandCount) {
                        val mb = prefs.getInt("eq_b$b", 0).coerceIn(minMb, maxMb)
                        e.setBandLevel(b.toShort(), mb.toShort())
                    }
                }
            }
        } catch (t: Throwable) {
            eq = null
        }
    }

    fun setEnabled(on: Boolean) {
        enabled = on
        try { eq?.enabled = on } catch (t: Throwable) { }
        prefs.edit().putBoolean("eq_on", on).apply()
    }

    fun centerHz(band: Int): Int = try { (eq!!.getCenterFreq(band.toShort()) / 1000) } catch (t: Throwable) { 0 }

    fun level(band: Int): Int = try { eq!!.getBandLevel(band.toShort()).toInt() } catch (t: Throwable) { 0 }

    fun setLevel(band: Int, mb: Int) {
        val v = mb.coerceIn(minMb, maxMb)
        try { eq?.setBandLevel(band.toShort(), v.toShort()) } catch (t: Throwable) { return }
        preset = -1
        saveLevels()
    }

    /** Slider 0..100 <-> millibels. */
    fun progressToMb(p: Int): Int = minMb + (p * (maxMb - minMb)) / 100
    fun mbToProgress(mb: Int): Int = if (maxMb == minMb) 50 else ((mb - minMb) * 100) / (maxMb - minMb)

    val presetCount: Int get() = try { eq!!.numberOfPresets.toInt() } catch (t: Throwable) { 0 }
    fun presetName(i: Int): String = try { eq!!.getPresetName(i.toShort()) } catch (t: Throwable) { "" }

    fun usePreset(i: Int) {
        try { eq?.usePreset(i.toShort()) } catch (t: Throwable) { return }
        preset = i
        saveLevels()
    }

    private fun saveLevels() {
        val ed = prefs.edit().putInt("eq_preset", preset)
        for (b in 0 until bandCount) ed.putInt("eq_b$b", level(b))
        ed.apply()
    }

    fun release() {
        try { eq?.release() } catch (t: Throwable) { }
        eq = null
    }
}
