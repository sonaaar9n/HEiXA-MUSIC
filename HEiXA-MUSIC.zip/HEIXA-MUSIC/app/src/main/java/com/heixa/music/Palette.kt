package com.heixa.music

import android.graphics.Bitmap
import android.graphics.Color

/** Apple-Music-like colour: one vivid colour per song, taken from its artwork (or its title). */
object Palette {
    val DEFAULT = 0xFFFA2D48.toInt()

    fun fromTitle(title: String): Int {
        val h = ((title.hashCode().toLong() and 0x7fffffff) % 360).toFloat()
        return Color.HSVToColor(floatArrayOf(h, 0.65f, 0.95f))
    }

    fun fromBitmap(b: Bitmap, fallback: Int): Int {
        return try {
            val s = Bitmap.createScaledBitmap(b, 12, 12, true)
            val hsv = FloatArray(3)
            var best = FloatArray(3)
            var bestScore = -1f
            for (y in 0 until 12) for (x in 0 until 12) {
                Color.colorToHSV(s.getPixel(x, y), hsv)
                val score = hsv[1] * hsv[2]
                if (score > bestScore) { bestScore = score; best = hsv.copyOf() }
            }
            if (s !== b) s.recycle()
            if (bestScore < 0.15f) return fallback
            best[1] = best[1].coerceIn(0.45f, 0.95f)
            best[2] = best[2].coerceIn(0.75f, 1f)
            Color.HSVToColor(best)
        } catch (e: Exception) {
            fallback
        }
    }

    private fun hsv(c: Int, s: (Float) -> Float, v: (Float) -> Float): Int {
        val a = FloatArray(3)
        Color.colorToHSV(c, a)
        a[1] = s(a[1]); a[2] = v(a[2])
        return Color.HSVToColor(a)
    }

    /** Song-name colour: bright but readable on black. */
    fun text(c: Int): Int = hsv(c, { it.coerceAtMost(0.6f) }, { 1f })

    /** Soft glow used at the top of the Now Playing background. */
    fun glow(c: Int): Int = hsv(c, { it.coerceAtLeast(0.6f) }, { 0.42f })
}
