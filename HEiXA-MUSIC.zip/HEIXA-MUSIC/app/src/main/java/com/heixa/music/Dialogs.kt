package com.heixa.music

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

object Dialogs {

    fun equalizer(act: Activity, eq: EqController) {
        if (!eq.available) {
            AlertDialog.Builder(act).setTitle(R.string.equalizer).setMessage(R.string.eq_unavailable)
                .setPositiveButton(android.R.string.ok, null).show()
            return
        }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(24), act.dp(8), act.dp(24), act.dp(8))
        }
        val bars = ArrayList<SeekBar>()
        val labels = ArrayList<TextView>()
        val presetBtn = TextView(act)

        fun refresh() {
            presetBtn.text = act.getString(R.string.eq_preset) + ": " +
                if (eq.preset >= 0) eq.presetName(eq.preset) else act.getString(R.string.custom)
            for (b in bars.indices) {
                val mb = eq.level(b)
                bars[b].progress = eq.mbToProgress(mb)
                labels[b].text = freq(eq.centerHz(b)) + "   " + String.format(Locale.US, "%+.1f dB", mb / 100f)
            }
        }

        val sw = Switch(act).apply {
            text = act.getString(R.string.eq_enabled)
            setTextColor(Color.WHITE)
            isChecked = eq.enabled
            setOnCheckedChangeListener { _, on -> eq.setEnabled(on) }
        }
        box.addView(sw)

        presetBtn.setTextColor(Colors.RED)
        presetBtn.textSize = 15f
        presetBtn.setPadding(0, act.dp(14), 0, act.dp(10))
        presetBtn.setOnClickListener {
            val names = Array(eq.presetCount) { eq.presetName(it) }
            AlertDialog.Builder(act).setTitle(R.string.eq_preset)
                .setItems(names) { _, which -> eq.usePreset(which); refresh() }.show()
        }
        box.addView(presetBtn)

        for (b in 0 until eq.bandCount) {
            val label = TextView(act).apply { setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.START }
            val bar = SeekBar(act).apply {
                max = 100
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val mb = eq.progressToMb(p)
                        eq.setLevel(b, mb)
                        label.text = freq(eq.centerHz(b)) + "   " + String.format(Locale.US, "%+.1f dB", mb / 100f)
                        presetBtn.text = act.getString(R.string.eq_preset) + ": " + act.getString(R.string.custom)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            labels.add(label); bars.add(bar)
            box.addView(label)
            box.addView(bar)
        }
        refresh()

        AlertDialog.Builder(act).setTitle(R.string.equalizer)
            .setView(ScrollView(act).apply { addView(box) })
            .setPositiveButton(android.R.string.ok, null).show()
    }

    private fun freq(hz: Int): String =
        if (hz >= 1000) String.format(Locale.US, "%.1f kHz", hz / 1000f) else "$hz Hz"

    fun sleepTimer(act: Activity, svc: PlayerService) {
        val mins = intArrayOf(15, 30, 45, 60, 90)
        val items = ArrayList<String>()
        for (m in mins) items.add(act.getString(R.string.timer_minutes, m))
        val active = svc.sleepRemaining() > 0
        if (active) items.add(act.getString(R.string.timer_cancel))
        AlertDialog.Builder(act).setTitle(R.string.sleep_timer)
            .setItems(items.toTypedArray()) { _, which ->
                if (which < mins.size) svc.startSleep(mins[which] * 60_000L) else svc.cancelSleep()
            }.show()
    }

    fun language(act: Activity) {
        val codes = arrayOf("", "en", "hi")
        val names = arrayOf(act.getString(R.string.lang_system), "English", "हिन्दी")
        val cur = codes.indexOf(Loc.get(act)).coerceAtLeast(0)
        AlertDialog.Builder(act).setTitle(R.string.language)
            .setSingleChoiceItems(names, cur) { d, which ->
                d.dismiss()
                if (codes[which] != Loc.get(act)) {
                    Loc.set(act, codes[which])
                    act.recreate()
                }
            }.show()
    }
}
