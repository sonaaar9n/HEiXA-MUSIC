package com.heixa.music

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Full-screen player: colour glow from the artwork, accent-coloured song name, dot-matrix clock. */
class NowPlayingView(private val act: MainActivity) : FrameLayout(act) {

    var service: PlayerService? = null

    private val glow = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.BLACK))
    private val art = ImageView(act)
    private val title = TextView(act)
    private val artist = TextView(act)
    private val seek = SeekBar(act)
    private val elapsed = DotTextView(act)
    private val total = DotTextView(act)
    private val timerLeft = DotTextView(act)
    private val col = LinearLayout(act)
    private var playBtn: ImageButton
    private var shuffleBtn: ImageButton
    private var repeatBtn: ImageButton
    private var tracking = false

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            val s = service
            if (isShown && s != null && (s.state == PlayerService.State.PLAYING || s.sleepRemaining() > 0)) {
                postDelayed(this, 500)
            }
        }
    }

    init {
        background = glow
        isClickable = true // swallow touches so the list below never reacts

        col.orientation = LinearLayout.VERTICAL
        col.setPadding(act.dp(24), act.dp(8), act.dp(24), act.dp(16))
        addView(col, FrameLayout.LayoutParams(-1, -1))

        // top bar
        val top = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(act.iconButton(R.drawable.ic_down, 48, Color.WHITE, R.string.close) { act.hideNowPlaying() })
        top.addView(TextView(act).apply {
            text = act.getString(R.string.now_playing)
            textSize = 12f
            letterSpacing = 0.2f
            setTextColor(Colors.DIM)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(View(act), LinearLayout.LayoutParams(act.dp(48), act.dp(48)))
        col.addView(top)

        // artwork
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.clipToOutline = true
        art.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, act.dp(18).toFloat()) }
        }
        col.addView(art, LinearLayout.LayoutParams(act.dp(260), act.dp(260)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = act.dp(20)
            bottomMargin = act.dp(24)
        })

        // title + artist
        title.textSize = 24f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        artist.textSize = 16f
        artist.setTextColor(0xB3FFFFFF.toInt())
        artist.maxLines = 1
        artist.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(title)
        col.addView(artist, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(2) })

        // seek bar + dot-matrix times
        seek.setPadding(act.dp(2), 0, act.dp(2), 0)
        seek.progressBackgroundTintList = ColorStateList.valueOf(0x44FFFFFF)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) elapsed.text = fmtTime(p.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { tracking = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                tracking = false
                service?.seekTo(s?.progress ?: 0)
            }
        })
        col.addView(seek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(20) })
        val times = LinearLayout(act).apply { gravity = Gravity.CENTER_VERTICAL }
        elapsed.setDot(3, Color.WHITE)
        total.setDot(3, Colors.DIM)
        times.addView(elapsed)
        times.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        times.addView(total)
        col.addView(times, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(6) })

        // transport controls
        val controls = LinearLayout(act).apply { gravity = Gravity.CENTER }
        shuffleBtn = act.iconButton(R.drawable.ic_shuffle, 48, Colors.DIM, R.string.shuffle) { service?.toggleShuffle() }
        repeatBtn = act.iconButton(R.drawable.ic_repeat, 48, Colors.DIM, R.string.repeat) { service?.cycleRepeat() }
        playBtn = act.iconButton(R.drawable.ic_play, 72, Color.BLACK, R.string.play) { service?.toggle() }
        playBtn.background = act.pill(Color.WHITE, 36)
        controls.addView(shuffleBtn)
        controls.addView(act.iconButton(R.drawable.ic_prev, 56, Color.WHITE, R.string.prev) { service?.previous() })
        controls.addView(playBtn, LinearLayout.LayoutParams(act.dp(72), act.dp(72)).apply {
            marginStart = act.dp(8); marginEnd = act.dp(8)
        })
        controls.addView(act.iconButton(R.drawable.ic_next, 56, Color.WHITE, R.string.next) { service?.next() })
        controls.addView(repeatBtn)
        col.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(18) })

        // bottom tools
        val tools = LinearLayout(act).apply { gravity = Gravity.CENTER }
        tools.addView(act.iconButton(R.drawable.ic_equalizer, 48, Color.WHITE, R.string.equalizer) {
            service?.let { Dialogs.equalizer(act, it.eq) }
        })
        tools.addView(act.iconButton(R.drawable.ic_timer, 48, Color.WHITE, R.string.sleep_timer) {
            service?.let { Dialogs.sleepTimer(act, it) }
        })
        timerLeft.setDot(3, Colors.RED)
        tools.addView(timerLeft, LinearLayout.LayoutParams(-2, -2).apply { marginStart = act.dp(8) })
        col.addView(tools, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(14) })
    }

    /** Re-draws everything from the service state. Called on every service change. */
    fun update() {
        val s = service ?: return
        val t = s.queue.current() ?: return
        val c = s.accent
        val txt = Palette.text(c)

        glow.colors = intArrayOf(Palette.glow(c), Color.BLACK)
        title.text = t.title
        title.setTextColor(txt)
        artist.text = t.artistLabel(act)

        val b = s.art
        if (b != null) {
            art.setPadding(0, 0, 0, 0)
            art.background = null
            art.clearColorFilter()
            art.setImageBitmap(b)
        } else {
            val p = act.dp(80)
            art.setPadding(p, p, p, p)
            art.background = act.pill(Palette.glow(c), 18)
            art.setImageResource(R.drawable.ic_music)
            art.setColorFilter(txt)
        }

        playBtn.setImageResource(if (s.playing) R.drawable.ic_pause else R.drawable.ic_play)
        shuffleBtn.setColorFilter(if (s.queue.shuffle) txt else Colors.DIM)
        repeatBtn.setImageResource(if (s.queue.repeat == PlayQueue.Repeat.ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatBtn.setColorFilter(if (s.queue.repeat == PlayQueue.Repeat.OFF) Colors.DIM else txt)

        seek.max = t.durationMs.toInt()
        seek.progressTintList = ColorStateList.valueOf(txt)
        seek.thumbTintList = ColorStateList.valueOf(txt)
        total.text = fmtTime(t.durationMs)
        updateProgress()
        removeCallbacks(ticker)
        if (isShown) post(ticker)
    }

    private fun updateProgress() {
        val s = service ?: return
        if (!tracking) {
            val p = s.position()
            seek.progress = p
            elapsed.text = fmtTime(p.toLong())
        }
        val rem = s.sleepRemaining()
        timerLeft.text = if (rem > 0) fmtTime(rem) else ""
    }

    fun stopTicker() { removeCallbacks(ticker) }
}
