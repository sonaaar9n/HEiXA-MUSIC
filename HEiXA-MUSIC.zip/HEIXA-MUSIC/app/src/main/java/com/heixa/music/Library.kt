package com.heixa.music

import android.content.ContentResolver
import android.media.MediaMetadataRetriever
import android.provider.MediaStore.Audio.Media

/**
 * Reads the whole music library with ONE MediaStore query (fast), groups it by folder.
 * MediaMetadataRetriever is used only when MediaStore has no duration for a file.
 */
object Library {
    @Volatile var tracks: List<Track> = emptyList()
        private set
    @Volatile var folders: List<Folder> = emptyList()
        private set
    @Volatile var loaded = false
        private set

    private val EXT = setOf("mp3", "m4a", "aac", "wav", "ogg", "flac")

    fun scan(cr: ContentResolver) {
        val list = ArrayList<Track>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.ALBUM, Media.ALBUM_ID, Media.DURATION, Media.DATA)
        try {
            cr.query(
                Media.EXTERNAL_CONTENT_URI, proj, "${Media.IS_MUSIC} != 0", null,
                "${Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val path = c.getString(6) ?: continue
                    if (path.substringAfterLast('.', "").lowercase() !in EXT) continue
                    var dur = c.getLong(5)
                    if (dur <= 0) dur = probeDuration(path)
                    if (dur <= 0) continue // corrupt / empty file: never enters the library
                    val raw = c.getString(1)
                    val title = if (raw.isNullOrBlank()) {
                        path.substringAfterLast('/').substringBeforeLast('.')
                    } else raw.trim()
                    list.add(Track(c.getLong(0), title, clean(c.getString(2)), clean(c.getString(3)), c.getLong(4), dur, path))
                }
            }
        } catch (e: Exception) {
            // Permission revoked mid-scan etc.: keep whatever we have.
        }
        val byFolder = LinkedHashMap<String, MutableList<Track>>()
        for (t in list) byFolder.getOrPut(t.folder) { ArrayList() }.add(t)
        folders = byFolder.map { Folder(it.key, it.value) }.sortedBy { it.name.lowercase() }
        tracks = list
        loaded = true
    }

    /** "Internal/Music/Rock" or "SD/Music" instead of the raw path. */
    fun where(path: String): String = when {
        path.startsWith("/storage/emulated/0") -> "Internal" + path.removePrefix("/storage/emulated/0")
        path.startsWith("/storage/") -> "SD" + path.removePrefix("/storage/").dropWhile { it != '/' }
        else -> path
    }

    private fun clean(s: String?): String = if (s.isNullOrBlank() || s == "<unknown>") "" else s.trim()

    private fun probeDuration(path: String): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }
}
