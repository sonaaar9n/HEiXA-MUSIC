package com.heixa.music

import kotlin.random.Random

/**
 * Pure queue logic (no Android): list + pointer, shuffle order, repeat modes.
 * [order] maps queue position -> index in [tracks]; without shuffle it is 0..n-1.
 */
class PlayQueue {
    enum class Repeat { OFF, ALL, ONE }

    var tracks: List<Track> = emptyList()
        private set
    var shuffle = false
        private set
    var repeat = Repeat.OFF

    private var order = IntArray(0)
    private var pos = -1

    val size: Int get() = tracks.size

    fun current(): Track? = if (pos in order.indices) tracks[order[pos]] else null

    fun set(list: List<Track>, startIndex: Int) {
        tracks = list
        rebuild(startIndex.coerceIn(0, maxOf(0, list.size - 1)))
    }

    fun setShuffle(on: Boolean) {
        if (on == shuffle) return
        val cur = if (pos in order.indices) order[pos] else 0
        shuffle = on
        rebuild(cur)
    }

    private fun rebuild(first: Int) {
        val n = tracks.size
        order = IntArray(n) { it }
        if (n == 0) { pos = -1; return }
        if (shuffle) {
            for (i in n - 1 downTo 1) {
                val j = Random.nextInt(i + 1)
                val t = order[i]; order[i] = order[j]; order[j] = t
            }
            val at = order.indexOf(first)
            order[at] = order[0]; order[0] = first
            pos = 0
        } else {
            pos = first
        }
    }

    /**
     * Next track.
     * - auto (song ended): REPEAT_ONE replays the same song; at the end of the queue
     *   REPEAT_ALL wraps to the start, REPEAT_OFF returns null (= stop).
     * - manual (Next button): always moves on and wraps at the end.
     * [skipRepeatOne] is used when skipping a broken file.
     */
    fun next(manual: Boolean, skipRepeatOne: Boolean = false): Track? {
        if (order.isEmpty()) return null
        if (!manual && !skipRepeatOne && repeat == Repeat.ONE) return current()
        if (pos + 1 < order.size) { pos++; return current() }
        if (manual || repeat == Repeat.ALL) { pos = 0; return current() }
        return null
    }

    /** Previous track, or null which means "restart the current song". */
    fun previous(positionMs: Int): Track? {
        if (order.isEmpty() || positionMs > 3000) return null
        if (pos > 0) { pos--; return current() }
        if (repeat == Repeat.ALL) { pos = order.size - 1; return current() }
        return null
    }

    fun rewind() { if (order.isNotEmpty()) pos = 0 }
}
