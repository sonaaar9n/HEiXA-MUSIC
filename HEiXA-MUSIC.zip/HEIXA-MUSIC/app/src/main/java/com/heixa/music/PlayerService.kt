package com.heixa.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size
import android.widget.Toast
import java.util.concurrent.Executors

/**
 * The whole playback engine lives here: MediaPlayer, queue, audio focus, MediaSession,
 * notification, noisy-receiver, sleep timer and equalizer. The UI only binds and renders.
 *
 * States: IDLE -> PREPARING -> PREPARED -> PLAYING <-> PAUSED, ERROR when nothing is playable.
 * A fresh MediaPlayer is created for every song and the old one released, so a stale player
 * can never leave us stuck on "pause -> play does nothing".
 */
class PlayerService : Service() {

    enum class State { IDLE, PREPARING, PREPARED, PLAYING, PAUSED, ERROR }

    interface Listener { fun onPlayerChanged() }

    inner class LocalBinder : Binder() {
        val service: PlayerService get() = this@PlayerService
    }

    companion object {
        const val ACTION_TOGGLE = "com.heixa.music.TOGGLE"
        const val ACTION_NEXT = "com.heixa.music.NEXT"
        const val ACTION_PREV = "com.heixa.music.PREV"
        const val ACTION_STOP = "com.heixa.music.STOP"
        private const val CHANNEL = "playback"
        private const val NOTIF_ID = 7
        private val ATTRS: AudioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
    }

    // ---- public state (read by the UI) ----
    val queue = PlayQueue()
    var state = State.IDLE
        private set
    var art: Bitmap? = null
        private set
    var accent: Int = Palette.DEFAULT
        private set
    lateinit var eq: EqController
        private set

    /** True when the user's intent is "music on" (playing or about to play). */
    val playing: Boolean get() = state == State.PLAYING || (state == State.PREPARING && wantPlay)

    // ---- internals ----
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<Listener>()
    private val artExec = Executors.newSingleThreadExecutor()
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private lateinit var audio: AudioManager
    private lateinit var session: MediaSession
    private lateinit var prefs: SharedPreferences

    private var player: MediaPlayer? = null
    private var sessionId = 0
    private var focusRequest: AudioFocusRequest? = null
    private var resumeOnFocus = false
    private var wantPlay = false
    private var pendingSeek = 0
    private var lastPos = 0
    private var errorStreak = 0
    private var inForeground = false
    private var noisyRegistered = false
    private var destroyed = false
    private var sleepEnd = 0L

    private val binder = LocalBinder()

    override fun attachBaseContext(base: Context) = super.attachBaseContext(Loc.wrap(base))

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AudioManager::class.java)
        prefs = getSharedPreferences("heixa", MODE_PRIVATE)
        sessionId = audio.generateAudioSessionId()
        eq = EqController(sessionId, prefs)
        queue.setShuffle(prefs.getBoolean("shuffle", false))
        queue.repeat = PlayQueue.Repeat.values()[prefs.getInt("repeat", 0).coerceIn(0, 2)]
        session = MediaSession(this, "HEiXA").also {
            it.setCallback(sessionCb)
            it.isActive = true
        }
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
                .apply { setShowBadge(false) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> if (queue.current() == null) { dropNotification(); stopSelf() } else toggle()
            ACTION_NEXT -> next()
            ACTION_PREV -> previous()
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    /** UI went away. If nothing is playing and no notification is shown, the service has no reason to live. */
    override fun onUnbind(intent: Intent?): Boolean {
        if (state == State.IDLE || state == State.PREPARED || state == State.ERROR) stopSelf()
        return false
    }

    /** App swiped from recents: keep playing music, but never leave an idle/paused ghost behind. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (state != State.PLAYING) stopAll()
    }

    override fun onDestroy() {
        destroyed = true
        cancelSleep()
        unregisterNoisy()
        releasePlayer()
        abandonFocus()
        eq.release()
        session.release()
        main.removeCallbacksAndMessages(null)
        artExec.shutdownNow()
        listeners.clear()
        super.onDestroy()
    }

    // ===================================================================== public controls

    fun addListener(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    fun playQueue(list: List<Track>, index: Int) {
        if (list.isEmpty()) return
        queue.set(list, index)
        errorStreak = 0
        load(true, 0)
    }

    /** Re-opens the last played song (paused) when the app starts. */
    fun restore(list: List<Track>) {
        if (queue.current() != null || list.isEmpty()) return
        val idx = list.indexOfFirst { it.id == prefs.getLong("last_id", -1L) }
        if (idx < 0) return
        queue.set(list, idx)
        load(false, prefs.getInt("last_pos", 0))
    }

    fun toggle() { if (playing) pause() else play() }

    fun play() {
        when (state) {
            State.PLAYING -> {}
            State.PREPARING -> { wantPlay = true; refreshNotification(); notifyUi() }
            State.PREPARED, State.PAUSED -> if (player != null) startPlayback() else load(true, lastPos)
            State.IDLE, State.ERROR -> if (queue.current() != null) load(true, lastPos)
        }
    }

    /** User pause: never auto-resumes. */
    fun pause() {
        resumeOnFocus = false
        if (state == State.PREPARING) { wantPlay = false; refreshNotification(); notifyUi(); return }
        pauseInternal()
    }

    fun next() {
        if (queue.next(manual = true) == null) return
        errorStreak = 0
        load(true, 0)
    }

    fun previous() {
        val t = queue.previous(position())
        if (t == null) {
            if (queue.current() == null) return
            if (state == State.PLAYING || state == State.PAUSED || state == State.PREPARED) seekTo(0) else load(true, 0)
        } else {
            errorStreak = 0
            load(true, 0)
        }
    }

    fun seekTo(ms: Int) {
        when (state) {
            State.PREPARING -> pendingSeek = ms
            State.PLAYING, State.PAUSED, State.PREPARED -> {
                try { player?.seekTo(ms) } catch (e: IllegalStateException) { }
                lastPos = ms
                updateSession()
            }
            else -> lastPos = ms
        }
        notifyUi()
    }

    fun toggleShuffle() {
        queue.setShuffle(!queue.shuffle)
        prefs.edit().putBoolean("shuffle", queue.shuffle).apply()
        notifyUi()
    }

    fun cycleRepeat() {
        val v = PlayQueue.Repeat.values()
        queue.repeat = v[(queue.repeat.ordinal + 1) % v.size]
        prefs.edit().putInt("repeat", queue.repeat.ordinal).apply()
        notifyUi()
    }

    fun position(): Int = when (state) {
        State.PLAYING, State.PAUSED, State.PREPARED -> try { player?.currentPosition ?: lastPos } catch (e: IllegalStateException) { lastPos }
        State.PREPARING -> pendingSeek
        else -> lastPos
    }

    /** Full stop: release everything, remove the notification and end the service. */
    fun stopAll() {
        cancelSleep()
        wantPlay = false
        resumeOnFocus = false
        if (player != null) savePos()
        unregisterNoisy()
        releasePlayer()
        abandonFocus()
        moveTo(State.IDLE)
        dropNotification()
        stopSelf()
    }

    // ---- sleep timer: elapsedRealtime based, immune to wall-clock changes ----
    private val sleepRunnable = object : Runnable {
        override fun run() {
            val rem = sleepEnd - SystemClock.elapsedRealtime()
            if (rem > 500) { main.postDelayed(this, rem); return }
            sleepEnd = 0
            pause()
            notifyUi()
        }
    }

    fun startSleep(ms: Long) {
        main.removeCallbacks(sleepRunnable)
        sleepEnd = SystemClock.elapsedRealtime() + ms
        main.postDelayed(sleepRunnable, ms)
        notifyUi()
    }

    fun cancelSleep() {
        main.removeCallbacks(sleepRunnable)
        sleepEnd = 0
        notifyUi()
    }

    fun sleepRemaining(): Long =
        if (sleepEnd == 0L) 0L else maxOf(0L, sleepEnd - SystemClock.elapsedRealtime())

    // ===================================================================== player engine

    private fun load(autoPlay: Boolean, startMs: Int) {
        releasePlayer()
        val t = queue.current()
        if (t == null) { moveTo(State.IDLE); return }
        wantPlay = autoPlay
        pendingSeek = startMs
        lastPos = startMs
        prefs.edit().putLong("last_id", t.id).putInt("last_pos", startMs).apply()
        onTrackChanged(t)
        moveTo(State.PREPARING)

        val mp = MediaPlayer()
        player = mp
        try {
            if (sessionId > 0) mp.audioSessionId = sessionId
            mp.setAudioAttributes(ATTRS)
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(applicationContext, t.uri)
            mp.setOnPreparedListener { if (it === player) onPrepared() }
            mp.setOnCompletionListener { if (it === player) onCompleted() }
            mp.setOnErrorListener { p, _, _ -> if (p === player) onPlayerError(); true }
            mp.prepareAsync()
        } catch (e: Exception) {
            onPlayerError()
        }
    }

    private fun onPrepared() {
        errorStreak = 0
        val mp = player ?: return
        if (pendingSeek > 0) {
            try { mp.seekTo(pendingSeek) } catch (e: IllegalStateException) { }
            pendingSeek = 0
        }
        moveTo(State.PREPARED)
        if (wantPlay) startPlayback()
    }

    private fun startPlayback() {
        if (!requestFocus()) {
            wantPlay = false
            moveTo(State.PAUSED)
            return
        }
        doStart()
    }

    private fun doStart() {
        val mp = player ?: return
        try {
            mp.setVolume(1f, 1f)
            mp.start()
        } catch (e: IllegalStateException) {
            load(true, lastPos) // player was in a bad state: rebuild it and continue
            return
        }
        wantPlay = false
        resumeOnFocus = false
        registerNoisy()
        moveTo(State.PLAYING)
    }

    private fun pauseInternal() {
        if (state != State.PLAYING) return
        try { player?.pause() } catch (e: IllegalStateException) { }
        unregisterNoisy()
        savePos()
        moveTo(State.PAUSED)
    }

    private fun onCompleted() {
        unregisterNoisy()
        lastPos = 0
        val n = queue.next(manual = false)
        if (n == null) {
            // End of queue, repeat off: go back to the first song, stopped.
            queue.rewind()
            abandonFocus()
            load(false, 0)
        } else {
            load(true, 0)
        }
    }

    /** Corrupt / deleted / unplayable file: skip it, never crash, never loop forever. */
    private fun onPlayerError() {
        val keepPlaying = wantPlay || state == State.PLAYING
        unregisterNoisy()
        releasePlayer()
        main.post { skipBroken(keepPlaying) }
    }

    private fun skipBroken(keepPlaying: Boolean) {
        if (destroyed) return
        errorStreak++
        if (errorStreak >= maxOf(1, queue.size)) {
            errorStreak = 0
            wantPlay = false
            abandonFocus()
            moveTo(State.ERROR)
            return
        }
        Toast.makeText(this, R.string.skipped, Toast.LENGTH_SHORT).show()
        val n = queue.next(manual = false, skipRepeatOne = true)
        if (n == null) {
            queue.rewind()
            errorStreak = 0
            wantPlay = false
            moveTo(State.ERROR)
            return
        }
        load(keepPlaying, 0)
    }

    private fun releasePlayer() {
        val p = player ?: return
        player = null
        p.setOnPreparedListener(null)
        p.setOnCompletionListener(null)
        p.setOnErrorListener(null)
        try { p.release() } catch (e: Exception) { }
    }

    private fun savePos() {
        lastPos = position()
        prefs.edit().putInt("last_pos", lastPos).apply()
    }

    // ===================================================================== audio focus

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                duck(false)
                if (resumeOnFocus && state == State.PAUSED) { resumeOnFocus = false; doStart() }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                pauseInternal()
                abandonFocus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (state == State.PLAYING) { resumeOnFocus = true; pauseInternal() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (state == State.PLAYING) duck(true)
            }
            else -> {}
        }
    }

    private fun requestFocus(): Boolean {
        val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(ATTRS)
            .setOnAudioFocusChangeListener(focusListener, main)
            .build().also { focusRequest = it }
        return audio.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    /** Focus is kept while paused (so resume always works); released only on LOSS, end or stop. */
    private fun abandonFocus() {
        focusRequest?.let { audio.abandonAudioFocusRequest(it) }
    }

    private fun duck(on: Boolean) {
        val v = if (on) 0.2f else 1f
        try { player?.setVolume(v, v) } catch (e: IllegalStateException) { }
    }

    // ===================================================================== headphones unplugged

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (state == State.PLAYING) { resumeOnFocus = false; pauseInternal() }
        }
    }

    private fun registerNoisy() {
        if (noisyRegistered) return
        registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        noisyRegistered = true
    }

    private fun unregisterNoisy() {
        if (!noisyRegistered) return
        try { unregisterReceiver(noisyReceiver) } catch (e: Exception) { }
        noisyRegistered = false
    }

    // ===================================================================== artwork

    private fun onTrackChanged(t: Track) {
        art = null
        accent = Palette.fromTitle(t.title)
        updateMetadata()
        val id = t.id
        artExec.execute {
            val b = loadArt(t)
            val c = if (b != null) Palette.fromBitmap(b, accent) else null
            main.post {
                if (!destroyed && queue.current()?.id == id) {
                    art = b
                    if (c != null) accent = c
                    updateMetadata()
                    refreshNotification()
                    notifyUi()
                }
            }
        }
    }

    private fun loadArt(t: Track): Bitmap? = try {
        var b: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
            contentResolver.loadThumbnail(t.uri, Size(512, 512), null)
        } else {
            decode(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId), 512)
        }
        if (b != null && b.config == Bitmap.Config.HARDWARE) b = b.copy(Bitmap.Config.ARGB_8888, false)
        b
    } catch (e: Exception) {
        null
    }

    private fun decode(u: Uri, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth > 0 && o.outWidth / (s * 2) >= max) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    // ===================================================================== session + notification

    private fun moveTo(s: State) {
        state = s
        updateSession()
        refreshNotification()
        notifyUi()
    }

    private fun notifyUi() {
        for (l in listeners.toList()) l.onPlayerChanged()
    }

    private val sessionCb = object : MediaSession.Callback() {
        override fun onPlay() { play() }
        override fun onPause() { pause() }
        override fun onSkipToNext() { next() }
        override fun onSkipToPrevious() { previous() }
        override fun onSeekTo(pos: Long) { seekTo(pos.toInt()) }
        override fun onStop() { stopAll() }
    }

    private fun updateSession() {
        val st = when (state) {
            State.PLAYING -> PlaybackState.STATE_PLAYING
            State.PAUSED, State.PREPARED -> PlaybackState.STATE_PAUSED
            State.PREPARING -> PlaybackState.STATE_BUFFERING
            State.ERROR -> PlaybackState.STATE_ERROR
            State.IDLE -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
        session.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(st, position().toLong(), if (state == State.PLAYING) 1f else 0f, SystemClock.elapsedRealtime())
                .build()
        )
    }

    private fun updateMetadata() {
        val t = queue.current() ?: return
        val b = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artistLabel(this))
            .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs)
        art?.let { b.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
        session.setMetadata(b.build())
    }

    private fun svcIntent(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, PlayerService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun action(icon: Int, label: Int, action: String, code: Int): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, icon), getString(label), svcIntent(action, code)).build()

    private fun buildNotification(): Notification {
        val t = queue.current()
        val on = playing
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(t?.title ?: getString(R.string.app_name))
            .setContentText(t?.artistLabel(this) ?: "")
            .setLargeIcon(art)
            .setColor(accent)
            .setContentIntent(open)
            .setDeleteIntent(svcIntent(ACTION_STOP, 4)) // swiped away => really stop
            .setOngoing(on)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(R.drawable.ic_prev, R.string.prev, ACTION_PREV, 1))
            .addAction(
                if (on) action(R.drawable.ic_pause, R.string.pause, ACTION_TOGGLE, 2)
                else action(R.drawable.ic_play, R.string.play, ACTION_TOGGLE, 2)
            )
            .addAction(action(R.drawable.ic_next, R.string.next, ACTION_NEXT, 3))
            .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    /**
     * Playing  -> foreground service + ongoing notification.
     * Paused   -> detached (swipeable) notification, service stays only so the buttons work.
     * Anything else -> no notification at all.
     */
    private fun refreshNotification() {
        if (destroyed) return
        val show = (playing || state == State.PAUSED) && queue.current() != null
        if (!show) { dropNotification(); return }
        val n = buildNotification()
        if (playing) {
            if (!inForeground) startForegroundSafe(n) else nm.notify(NOTIF_ID, n)
        } else {
            if (inForeground) { stopForeground(STOP_FOREGROUND_DETACH); inForeground = false }
            nm.notify(NOTIF_ID, n)
        }
    }

    private fun startForegroundSafe(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
            inForeground = true
        } catch (e: Exception) {
            nm.notify(NOTIF_ID, n) // background-start restriction: keep playing, just not as a foreground service
        }
    }

    private fun dropNotification() {
        if (inForeground) { stopForeground(STOP_FOREGROUND_REMOVE); inForeground = false }
        nm.cancel(NOTIF_ID)
    }
}
