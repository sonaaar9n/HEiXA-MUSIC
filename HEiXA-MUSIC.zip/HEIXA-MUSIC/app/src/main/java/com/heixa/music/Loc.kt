package com.heixa.music

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** In-app language (framework only, no AppCompat). "" = follow the system. */
object Loc {
    fun get(ctx: Context): String =
        ctx.getSharedPreferences("heixa", Context.MODE_PRIVATE).getString("lang", "") ?: ""

    fun set(ctx: Context, code: String) {
        ctx.getSharedPreferences("heixa", Context.MODE_PRIVATE).edit().putString("lang", code).apply()
    }

    fun wrap(base: Context): Context {
        val code = get(base)
        if (code.isEmpty()) return base
        val loc = Locale(code)
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        return base.createConfigurationContext(cfg)
    }
}
