package com.heixa.music

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: RowAdapter
    private lateinit var list: ListView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptyBody: TextView
    private lateinit var emptyBtn: Button
    private lateinit var countText: TextView
    private lateinit var tabSongs: TextView
    private lateinit var tabFolders: TextView
    private lateinit var search: EditText
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var nowPlaying: NowPlayingView

    private var svc: PlayerService? = null
    private var tab = 0                       // 0 = songs, 1 = folders
    private var openFolder: Folder? = null    // inside a folder (shows its songs)
    private var shown: List<Track> = emptyList()
    private var shownFolders: List<Folder> = emptyList()
    private var query = ""
    private var scanning = false
    private var bound = false

    private val audioPerm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private val listener = object : PlayerService.Listener {
        override fun onPlayerChanged() { render() }
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as PlayerService.LocalBinder).service
            svc = s
            nowPlaying.service = s
            s.addListener(listener)
            if (Library.loaded) s.restore(Library.tracks)
            render()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            nowPlaying.service = null
        }
    }

    // ===================================================================== lifecycle

    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(Loc.wrap(newBase))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("heixa", MODE_PRIVATE)
        setContentView(buildUi())
        if (hasAudioPermission()) {
            scan()
        } else {
            showPermissionState()
            if (!prefs.getBoolean("asked", false)) requestAudioPermission()
        }
    }

    override fun onStart() {
        super.onStart()
        val i = Intent(this, PlayerService::class.java)
        startService(i)
        bound = bindService(i, conn, BIND_AUTO_CREATE)
        if (hasAudioPermission() && !Library.loaded) scan() // e.g. coming back from app settings
    }

    override fun onStop() {
        nowPlaying.stopTicker()
        svc?.removeListener(listener)
        svc = null
        nowPlaying.service = null
        if (bound) { bound = false; unbindService(conn) }
        super.onStop()
    }

    override fun onBackPressed() {
        when {
            nowPlaying.visibility == View.VISIBLE -> hideNowPlaying()
            search.visibility == View.VISIBLE -> closeSearch()
            openFolder != null -> { openFolder = null; applyList() }
            else -> super.onBackPressed()
        }
    }

    // ===================================================================== permission + scan

    private fun hasAudioPermission() = checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED

    private fun requestAudioPermission() {
        prefs.edit().putBoolean("asked", true).apply()
        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm)
        requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasAudioPermission()) scan() else showPermissionState()
    }

    /** Denied -> ask again. Denied with "don't ask again" -> open app settings. No crash either way. */
    private fun showPermissionState() {
        val blocked = prefs.getBoolean("asked", false) && !shouldShowRequestPermissionRationale(audioPerm)
        showEmpty(R.string.grant_title, R.string.grant_body, if (blocked) R.string.open_settings else R.string.grant_btn) {
            if (blocked) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            } else requestAudioPermission()
        }
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        if (!Library.loaded) showEmpty(R.string.scanning, null, null) {}
        Thread {
            Library.scan(contentResolver)
            runOnUiThread {
                scanning = false
                if (isDestroyed) return@runOnUiThread
                applyList()
                svc?.restore(Library.tracks)
                render()
            }
        }.start()
    }

    // ===================================================================== list handling

    private fun applyList() {
        val q = query.trim().lowercase()
        val folderMode = tab == 1 && openFolder == null
        if (!folderMode) {
            val base = openFolder?.tracks ?: Library.tracks
            shown = if (q.isEmpty()) base else base.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
            adapter.submit(shown.map { Row(it.id, it.title, it.artistLabel(this) + " • " + fmtTime(it.durationMs)) })
            countText.text = openFolder?.name ?: getString(R.string.songs_count, shown.size)
        } else {
            shownFolders = if (q.isEmpty()) Library.folders else Library.folders.filter { it.name.lowercase().contains(q) }
            adapter.submit(shownFolders.mapIndexed { i, f ->
                Row(-1L - i, f.name, getString(R.string.folder_sub, f.tracks.size, fmtLong(f.totalMs)) + " • " + Library.where(f.path))
            })
            countText.text = getString(R.string.folders_count, shownFolders.size)
        }
        styleTabs()
        if (adapter.count == 0 && q.isEmpty()) {
            if (!hasAudioPermission()) showPermissionState() else showEmpty(R.string.no_music, null, null) {}
        } else {
            emptyBox.visibility = View.GONE
            list.visibility = View.VISIBLE
        }
    }

    private fun showEmpty(title: Int, body: Int?, btn: Int?, onClick: () -> Unit) {
        list.visibility = View.GONE
        emptyBox.visibility = View.VISIBLE
        emptyTitle.setText(title)
        emptyBody.visibility = if (body == null) View.GONE else View.VISIBLE
        if (body != null) emptyBody.setText(body)
        emptyBtn.visibility = if (btn == null) View.GONE else View.VISIBLE
        if (btn != null) emptyBtn.setText(btn)
        emptyBtn.setOnClickListener { onClick() }
    }

    private fun styleTabs() {
        val songsOn = tab == 0
        tabSongs.background = if (songsOn) pill(Color.WHITE, 100) else null
        tabSongs.setTextColor(if (songsOn) Color.BLACK else Colors.DIM)
        tabFolders.background = if (!songsOn) pill(Color.WHITE, 100) else null
        tabFolders.setTextColor(if (!songsOn) Color.BLACK else Colors.DIM)
    }

    private fun onRowClick(pos: Int) {
        if (tab == 1 && openFolder == null) {
            openFolder = shownFolders.getOrNull(pos) ?: return
            closeSearch()
            applyList()
        } else {
            svc?.playQueue(shown, pos)
        }
    }

    // ===================================================================== rendering

    private fun render() {
        val s = svc ?: return
        val t = s.queue.current()
        adapter.playingColor = s.accent
        adapter.playingKey = t?.id ?: Long.MIN_VALUE
        adapter.notifyDataSetChanged()
        if (t == null) {
            mini.visibility = View.GONE
        } else {
            mini.visibility = View.VISIBLE
            miniTitle.text = t.title
            miniTitle.setTextColor(Palette.text(s.accent))
            miniArtist.text = t.artistLabel(this)
            miniPlay.setImageResource(if (s.playing) R.drawable.ic_pause else R.drawable.ic_play)
        }
        nowPlaying.update()
    }

    fun showNowPlaying() {
        if (svc?.queue?.current() == null) return
        nowPlaying.visibility = View.VISIBLE
        nowPlaying.translationY = nowPlaying.height.toFloat().coerceAtLeast(dp(600).toFloat())
        nowPlaying.animate().translationY(0f).setDuration(220).start()
        nowPlaying.update()
    }

    fun hideNowPlaying() {
        nowPlaying.animate().translationY(nowPlaying.height.toFloat()).setDuration(200).withEndAction {
            nowPlaying.visibility = View.GONE
            nowPlaying.stopTicker()
        }.start()
    }

    // ===================================================================== search + menu

    private fun openSearch() {
        search.visibility = View.VISIBLE
        search.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
    }

    private fun closeSearch() {
        if (search.visibility != View.VISIBLE) return
        search.setText("")
        search.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, R.string.rescan)
            menu.add(0, 2, 1, R.string.equalizer)
            menu.add(0, 3, 2, R.string.sleep_timer)
            menu.add(0, 4, 3, R.string.language)
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> if (hasAudioPermission()) scan() else requestAudioPermission()
                    2 -> svc?.let { s -> Dialogs.equalizer(this@MainActivity, s.eq) }
                    3 -> svc?.let { s -> Dialogs.sleepTimer(this@MainActivity, s) }
                    4 -> Dialogs.language(this@MainActivity)
                }
                true
            }
            show()
        }
    }

    // ===================================================================== UI construction

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Colors.BG)

        val home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // header: dot-matrix logo + search + menu
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(8), dp(2))
        }
        val logo = DotTextView(this).apply { text = "HEiXA"; setDot(4, Color.WHITE) }
        val logo2 = TextView(this).apply {
            text = "MUSIC"
            textSize = 12f
            letterSpacing = 0.3f
            setTextColor(Colors.RED)
            setPadding(dp(10), dp(14), 0, 0)
        }
        header.addView(logo)
        header.addView(logo2)
        header.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(iconButton(R.drawable.ic_search, 48, Color.WHITE, R.string.search_hint) { if (search.visibility == View.VISIBLE) closeSearch() else openSearch() })
        header.addView(iconButton(R.drawable.ic_more, 48, Color.WHITE, R.string.language) { showMenu(it) })
        home.addView(header)

        countText = TextView(this).apply {
            textSize = 13f
            setTextColor(Colors.DIM)
            setPadding(dp(20), 0, dp(20), dp(8))
        }
        home.addView(countText)

        search = EditText(this).apply {
            setHint(R.string.search_hint)
            setHintTextColor(Colors.DIM)
            setTextColor(Color.WHITE)
            textSize = 15f
            isSingleLine = true
            background = pill(Colors.CARD, 14)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            visibility = View.GONE
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; applyList() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        home.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), 0, dp(16), dp(8)) })

        // tabs
        val tabs = LinearLayout(this).apply { setPadding(dp(16), 0, dp(16), dp(8)) }
        tabSongs = makeTab(R.string.tab_songs) { tab = 0; openFolder = null; applyList() }
        tabFolders = makeTab(R.string.tab_folders) { tab = 1; openFolder = null; applyList() }
        tabs.addView(tabSongs)
        tabs.addView(tabFolders)
        home.addView(tabs)

        // list + empty state
        adapter = RowAdapter(this)
        list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            divider = null
            isFastScrollEnabled = true
            setSelector(android.R.color.transparent)
            setOnItemClickListener { _, _, pos, _ -> onRowClick(pos) }
        }
        emptyTitle = TextView(this).apply { textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        emptyBody = TextView(this).apply { textSize = 14f; setTextColor(Colors.DIM); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(20)) }
        emptyBtn = Button(this).apply {
            setTextColor(Color.BLACK)
            background = pill(Color.WHITE, 100)
            setPadding(dp(28), 0, dp(28), 0)
            isAllCaps = false
        }
        emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), 0, dp(32), 0)
            visibility = View.GONE
            addView(emptyTitle)
            addView(emptyBody)
            addView(emptyBtn, LinearLayout.LayoutParams(-2, dp(46)))
        }
        val content = FrameLayout(this)
        content.addView(list, FrameLayout.LayoutParams(-1, -1))
        content.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        home.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // mini player
        miniTitle = TextView(this).apply { textSize = 15f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(Color.WHITE) }
        miniArtist = TextView(this).apply { textSize = 12f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(Colors.DIM) }
        miniPlay = iconButton(R.drawable.ic_play, 48, Color.WHITE, R.string.play) { svc?.toggle() }
        mini = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = pill(Colors.CARD, 18)
            setPadding(dp(18), dp(4), dp(6), dp(4))
            visibility = View.GONE
            setOnClickListener { showNowPlaying() }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(miniTitle)
                addView(miniArtist)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(miniPlay)
            addView(iconButton(R.drawable.ic_next, 48, Color.WHITE, R.string.next) { svc?.next() })
        }
        home.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(10)) })

        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        nowPlaying = NowPlayingView(this).apply { visibility = View.GONE }
        root.addView(nowPlaying, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private fun makeTab(label: Int, onClick: () -> Unit) = TextView(this).apply {
        setText(label)
        textSize = 13f
        letterSpacing = 0.1f
        setPadding(dp(18), dp(8), dp(18), dp(8))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
    }
}
