package com.heixa.music

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** 5x7 dot-matrix glyphs. Only what the app needs: logo letters, digits, ':' '-' '.' and space. */
object DotFont {
    const val COLS = 5
    const val ROWS = 7
    private val glyphs = HashMap<Char, IntArray>()

    private fun g(c: Char, vararg rows: Int) { glyphs[c] = rows }

    init {
        g('0', 14, 17, 19, 21, 25, 17, 14)
        g('1', 4, 12, 4, 4, 4, 4, 14)
        g('2', 14, 17, 1, 2, 4, 8, 31)
        g('3', 30, 1, 1, 14, 1, 1, 30)
        g('4', 2, 6, 10, 18, 31, 2, 2)
        g('5', 31, 16, 30, 1, 1, 17, 14)
        g('6', 6, 8, 16, 30, 17, 17, 14)
        g('7', 31, 1, 2, 4, 8, 8, 8)
        g('8', 14, 17, 17, 14, 17, 17, 14)
        g('9', 14, 17, 17, 15, 1, 2, 12)
        g(':', 0, 4, 4, 0, 4, 4, 0)
        g('-', 0, 0, 0, 31, 0, 0, 0)
        g('.', 0, 0, 0, 0, 0, 0, 4)
        g(' ', 0, 0, 0, 0, 0, 0, 0)
        g('H', 17, 17, 17, 31, 17, 17, 17)
        g('E', 31, 16, 16, 30, 16, 16, 31)
        g('i', 4, 0, 12, 4, 4, 4, 14)
        g('X', 17, 17, 10, 4, 10, 17, 17)
        g('A', 14, 17, 17, 31, 17, 17, 17)
        g('M', 17, 27, 21, 21, 17, 17, 17)
        g('U', 17, 17, 17, 17, 17, 17, 14)
        g('S', 15, 16, 16, 14, 1, 1, 30)
        g('I', 14, 4, 4, 4, 4, 4, 14)
        g('C', 14, 17, 16, 16, 16, 17, 14)
    }

    fun glyph(c: Char): IntArray? = glyphs[c]
}

/** A tiny view that draws text as lit/unlit dots. Used only for accents (logo, clocks). */
class DotTextView(context: Context) : View(context) {
    private val on = Paint(Paint.ANTI_ALIAS_FLAG)
    private val off = Paint(Paint.ANTI_ALIAS_FLAG)
    private var step = context.dp(4).toFloat()

    var text: String = ""
        set(v) {
            if (v != field) { field = v; requestLayout(); invalidate() }
        }

    init {
        setDot(4, Color.WHITE)
    }

    /** [stepDp] = distance between dot centres. */
    fun setDot(stepDp: Int, color: Int) {
        step = context.dp(stepDp).toFloat()
        on.color = color
        off.color = (color and 0x00FFFFFF) or 0x26000000
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = if (text.isEmpty()) 0 else ((text.length * (DotFont.COLS + 1) - 1) * step).toInt()
        setMeasuredDimension(resolveSize(width, w), resolveSize((DotFont.ROWS * step).toInt(), h))
    }

    override fun onDraw(canvas: Canvas) {
        val r = step * 0.36f
        for (i in text.indices) {
            val rows = DotFont.glyph(text[i])
            for (row in 0 until DotFont.ROWS) {
                val bits = rows?.get(row) ?: 0
                for (col in 0 until DotFont.COLS) {
                    val lit = (bits shr (DotFont.COLS - 1 - col)) and 1 == 1
                    val cx = (i * (DotFont.COLS + 1) + col) * step + step / 2
                    canvas.drawCircle(cx, row * step + step / 2, r, if (lit) on else off)
                }
            }
        }
    }
}
