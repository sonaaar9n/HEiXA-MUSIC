plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Release signing: CI passes a keystore through environment variables.
// Without them the build falls back to the debug key so it still works locally.
val ksPath: String? = System.getenv("HEIXA_KEYSTORE")

android {
    namespace = "com.heixa.music"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.heixa.music"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        resourceConfigurations += listOf("en", "hi")
    }

    signingConfigs {
        if (ksPath != null && file(ksPath).exists()) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("HEIXA_KS_PASS")
                keyAlias = System.getenv("HEIXA_KEY_ALIAS")
                keyPassword = System.getenv("HEIXA_KS_PASS")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources {
            excludes += setOf("/META-INF/**", "/kotlin/**", "/DebugProbesKt.bin")
        }
    }
    lint { checkReleaseBuilds = false }
}

// No dependencies on purpose: pure Android framework + Kotlin stdlib (shrunk by R8).
